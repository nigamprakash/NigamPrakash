import { Component } from '@angular/core';
import { Movie } from '../movie.model';

@Component({
  selector: 'app-movies',
  templateUrl: './movies.component.html',
  styleUrls: ['./movies.component.css']
})
export class MoviesComponent {
  movies: Movie[] = [
    new Movie('Movie 1', 'Action', 'Director 1'),
    new Movie('Movie 2', 'Comedy', 'Director 2'),
    new Movie('Movie 3', 'Drama', 'Director 3'),
    new Movie('Movie 4', 'Thriller', 'Director 4'),
    new Movie('Movie 5', 'Sci-Fi', 'Director 5')
  ];
}
