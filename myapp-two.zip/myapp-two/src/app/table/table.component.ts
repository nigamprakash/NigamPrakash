import { Component } from '@angular/core';

@Component({
  selector: 'app-table',
  templateUrl: './table.component.html',
  styleUrls: ['./table.component.css']
})
export class TableComponent {
  tableStyle: any;

  constructor() {
    this.tableStyle = {
      'background-color': 'lightblue',
      'font-size': '16px',
      'color': 'black'
    };
  }
}
