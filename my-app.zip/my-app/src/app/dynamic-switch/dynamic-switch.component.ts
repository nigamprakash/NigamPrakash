import { Component } from '@angular/core';

@Component({
  selector: 'app-dynamic-switch',
  templateUrl: './dynamic-switch.component.html',
  styleUrls: ['./dynamic-switch.component.css']
})
export class DynamicSwitchComponent {
  switchValue: string;

  constructor() {
    this.switchValue = 'case1';
  }
}
