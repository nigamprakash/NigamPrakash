import { Component } from '@angular/core';

interface Car {
  make: string;
  model: string;
  year: number;
}

@Component({
  selector: 'app-cars',
  templateUrl: './cars.component.html',
  styleUrls: ['./cars.component.css']
})
export class CarsComponent {
  cars: Car[] = [
    { make: 'BMW', model: '3 Series', year: 2019 },
    { make: 'Toyota', model: 'Camry', year: 2020 },
    { make: 'Honda', model: 'Accord', year: 2018 },
    // Add more cars here...
  ];
}
