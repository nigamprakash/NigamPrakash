import { Component } from '@angular/core';

interface Car {
  make: string;
  model: string;
  year: number;
}

@Component({
  selector: 'app-cars',
  templateUrl: './cars.component.html',
  styleUrls: ['./cars.component.css']
})
export class CarsComponent {
  cars: Car[] = [
    { make: 'BMW', model: '3series', year: 2019 },
    { make: 'Ford', model: 'Mustang', year: 2020 },
    { make: 'Toyota', model: 'Camry', year: 2021 }
  ];

  showData: boolean = true;

  toggleData() {
    this.showData = !this.showData;
  }
}
