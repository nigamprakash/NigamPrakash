import { Component } from '@angular/core';

@Component({
  selector: 'app-comparison',
  templateUrl: './comparison.component.html',
  styleUrls: ['./comparison.component.css']
})
export class ComparisonComponent {
  result!: string;

  compareValues(): void {
    const x = 100;
    const y = 200;

    if (x > y) {
      this.result = 'x';
    } else if (y > x) {
      this.result = 'y';
    } else {
      this.result = '';
    }
  }
}
